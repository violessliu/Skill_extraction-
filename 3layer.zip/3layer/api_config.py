#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Together AI credentials and transport settings.

把 API key 填在下面的 TOGETHER_API_KEY，或者设置环境变量 TOGETHER_API_KEY。
Put your Together AI key in TOGETHER_API_KEY below, or export it as an
environment variable.

Resolution order (first non-empty wins):
    1. --llm_api_key on the command line
    2. environment variables listed in API_KEY_ENV_VARS
    3. the TOGETHER_API_KEY literal in this file

Do not commit this file once a real key is written into it.
"""

import os
from typing import Optional


# ============================================================
# Credentials
# ============================================================

# Paste your key here, e.g. "1a2b3c...". Leave empty to use the environment.
TOGETHER_API_KEY = "tgp_v1_EfYP7U8gBO-MnCPQU2eEjUf2GJ7nBAaAOPVbuwTIakg"

API_KEY_ENV_VARS = (
    "TOGETHER_API_KEY",
    "TOGETHERAI_API_KEY",
)

TOGETHER_BASE_URL = "https://api.together.xyz/v1"

BASE_URL_ENV_VAR = "TOGETHER_BASE_URL"


# ============================================================
# Transport
# ============================================================

# Seconds to wait for a single HTTP request before giving up.
REQUEST_TIMEOUT = 180.0

# Attempts per LLM call when the failure is transport-level
# (rate limit, connection reset, 5xx).
MAX_TRANSPORT_RETRIES = 6

# Exponential backoff between transport retries, in seconds.
RETRY_BASE_DELAY = 2.0
RETRY_MAX_DELAY = 60.0

# Attempts per LLM call when the response parses but is unusable
# (malformed JSON, missing selections).
MAX_CONTENT_RETRIES = 3

# Concurrent job descriptions in flight. Together enforces per-account
# request-rate limits; lower this if you see sustained 429 backoff.
INFER_WORKERS = 8


# ============================================================
# Resolution helpers
# ============================================================

def resolve_api_key(cli_key: Optional[str] = None) -> str:
    if cli_key:
        return cli_key.strip()

    for env_var in API_KEY_ENV_VARS:
        value = os.environ.get(env_var, "").strip()
        if value:
            return value

    if TOGETHER_API_KEY.strip():
        return TOGETHER_API_KEY.strip()

    raise RuntimeError(
        "No Together AI API key found.\n"
        "Set one of these and re-run:\n"
        f"  - environment variable {API_KEY_ENV_VARS[0]}\n"
        "  - the TOGETHER_API_KEY value in api_config.py\n"
        "  - the --llm_api_key command line flag\n"
        "Keys are created at https://api.together.ai/settings/api-keys"
    )


def resolve_base_url(cli_base_url: Optional[str] = None) -> str:
    if cli_base_url:
        return cli_base_url.strip().rstrip("/")

    env_value = os.environ.get(BASE_URL_ENV_VAR, "").strip()
    if env_value:
        return env_value.rstrip("/")

    return TOGETHER_BASE_URL.rstrip("/")


def mask_api_key(api_key: str) -> str:
    if not api_key:
        return "<empty>"
    if len(api_key) <= 8:
        return "*" * len(api_key)
    return f"{api_key[:4]}...{api_key[-4:]}"
