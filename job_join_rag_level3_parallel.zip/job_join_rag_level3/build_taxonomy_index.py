from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parent
SRC_DIR = PROJECT_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from job_skill_rag.config import (  # noqa: E402
    DEFAULT_EMBEDDING_MODEL,
    DEFAULT_INDEX_DIR,
    DEFAULT_TAXONOMY_FILE,
)
from job_skill_rag.taxonomy import load_taxonomy_csv, rag_text, save_metadata_jsonl  # noqa: E402


INDEX_VERSION = 4


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Build flattened level-3 Lightcast skill embeddings with Qwen3-Embedding."
    )
    parser.add_argument("--taxonomy-file", type=Path, default=DEFAULT_TAXONOMY_FILE)
    parser.add_argument("--index-dir", type=Path, default=DEFAULT_INDEX_DIR)
    parser.add_argument("--embedding-model", default=DEFAULT_EMBEDDING_MODEL)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument(
        "--device",
        default="cuda",
        help="Embedding device, e.g. cuda, cuda:1, or cpu.",
    )
    parser.add_argument(
        "--use-definition",
        action="store_true",
        help=(
            "Include the Lightcast definition in each taxonomy embedding document. "
            "Default is OFF: only the level-3 skill name is embedded."
        ),
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    try:
        import faiss
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        raise RuntimeError(
            "Install: pip install 'sentence-transformers>=5.4.0' 'transformers>=4.51.0' faiss-cpu"
        ) from exc

    skills = load_taxonomy_csv(args.taxonomy_file.resolve())
    print(f"Loaded taxonomy rows: {len(skills):,}")
    if args.use_definition:
        print("Embedding unit: Skill + Definition")
    else:
        print("Embedding unit: Skill only (former level 3; definition OFF)")

    encoder = SentenceTransformer(args.embedding_model, device=args.device)
    texts = [rag_text(skill, use_definition=args.use_definition) for skill in skills]
    embeddings = encoder.encode(
        texts,
        batch_size=args.batch_size,
        normalize_embeddings=True,
        convert_to_numpy=True,
        show_progress_bar=True,
    ).astype("float32")

    index = faiss.IndexFlatIP(embeddings.shape[1])
    index.add(embeddings)

    args.index_dir.mkdir(parents=True, exist_ok=True)
    faiss_path = args.index_dir / "taxonomy.faiss"
    metadata_path = args.index_dir / "taxonomy_metadata.jsonl"
    manifest_path = args.index_dir / "index_manifest.json"

    faiss.write_index(index, str(faiss_path))
    save_metadata_jsonl(skills, metadata_path, include_definition=args.use_definition)
    manifest_path.write_text(
        json.dumps(
            {
                "index_version": INDEX_VERSION,
                "embedding_model": args.embedding_model,
                "taxonomy_rows": len(skills),
                "embedding_dimension": int(embeddings.shape[1]),
                "document_format": (
                    "Skill + Definition"
                    if args.use_definition
                    else "Skill only (former level 3)"
                ),
                "use_definition": bool(args.use_definition),
                "normalized": True,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    # Backward-readable marker.
    (args.index_dir / "embedding_model.txt").write_text(args.embedding_model, encoding="utf-8")

    print(f"Saved FAISS index: {faiss_path}")
    print(f"Saved metadata:    {metadata_path}")
    print(f"Saved manifest:    {manifest_path}")


if __name__ == "__main__":
    main()
