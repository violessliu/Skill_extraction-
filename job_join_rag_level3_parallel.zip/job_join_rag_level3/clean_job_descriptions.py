from pathlib import Path
import html
import re
import pandas as pd


# ============================================================
# Configuration
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

INPUT_FILE = BASE_DIR / r"D:\job_join_direct_rag\data\sample_2021_2025_400.csv"
OUTPUT_FILE = BASE_DIR / "sample_2021_2025_400.csv"

SOURCE_COLUMN = "DESCRIPTION"
OUTPUT_COLUMN = "DESCRIPTION_CLEAN"

# These are useful for downstream LLM / RAG skill extraction.
REMOVE_URLS = True
REMOVE_EMAILS = True


# ============================================================
# Precompiled regex
# ============================================================

# Literal escaped unicode in scraped text, e.g. "\u2013", "\u2019"
RE_LITERAL_UNICODE = re.compile(
    r"\\u([0-9a-fA-F]{4})|\\U([0-9a-fA-F]{8})"
)

# Common inline HTML tags. We remove the tag but preserve its text.
RE_INLINE_HTML = re.compile(
    r"</?\s*(?:span|strong|b|em|i|u|h[1-6])\b[^>]*>",
    flags=re.I,
)

# Explicit URLs only. We intentionally do not remove every "something.com",
# because names such as Node.js and technology/product names should be preserved.
RE_URL = re.compile(
    r"(?i)(?:https?://|www\.)[^\s<>()]+"
)

RE_EMAIL = re.compile(
    r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b"
)

# Control characters except newline/tab.
RE_CONTROL = re.compile(
    r"[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]"
)

# Common bullet symbols only when they occur at the start of a line.
RE_BULLET = re.compile(
    r"^\s*[•●▪◦■►*]\s*"
)

RE_MULTI_SPACE = re.compile(r"[ \t]+")
RE_MANY_BLANK_LINES = re.compile(r"\n{3,}")


# ============================================================
# Cleaning helpers
# ============================================================

def _decode_literal_unicode(match):
    """
    Convert literal unicode escapes:
        \u2013 -> –
        \u2019 -> ’
    without decoding unrelated backslashes in the whole string.
    """
    hex_value = match.group(1) or match.group(2)

    try:
        return chr(int(hex_value, 16))
    except ValueError:
        return match.group(0)


def clean_description(
    text,
    remove_urls=REMOVE_URLS,
    remove_emails=REMOVE_EMAILS,
):
    """
    Conservative, general-purpose cleaner for job descriptions.

    It removes formatting / scraping noise while preserving semantic content.

    It DOES:
    - decode literal Unicode escapes such as \u2013
    - decode HTML entities such as &amp;
    - normalize line endings and invisible whitespace
    - convert common HTML structural tags into readable line breaks / bullets
    - remove common inline HTML formatting tags
    - optionally remove explicit URLs and email addresses
    - normalize bullets, spaces, and excessive blank lines

    It DOES NOT:
    - lowercase text
    - remove punctuation
    - remove stop words
    - delete company-overview sections
    - delete benefits sections
    - delete EEO / legal text by guessed keywords
    - rewrite or summarize the description

    This is intentional: semantic deletion should be a separate downstream step.
    """

    if pd.isna(text):
        return ""

    text = str(text)

    # --------------------------------------------------------
    # 1. Decode scraped / escaped text
    # --------------------------------------------------------

    text = RE_LITERAL_UNICODE.sub(
        _decode_literal_unicode,
        text,
    )

    # &amp; -> &, &lt; -> <, etc.
    text = html.unescape(text)

    # --------------------------------------------------------
    # 2. Normalize line endings and invisible whitespace
    # --------------------------------------------------------

    text = (
        text
        .replace("\r\n", "\n")
        .replace("\r", "\n")
        .replace("\u2028", "\n")
        .replace("\u2029", "\n")
        .replace("\u00A0", " ")
        .replace("\u200B", "")
        .replace("\ufeff", "")
    )

    # --------------------------------------------------------
    # 3. Handle common HTML while preserving structure
    # --------------------------------------------------------

    # <li>text -> "- text"
    text = re.sub(
        r"<\s*li\b[^>]*>",
        "\n- ",
        text,
        flags=re.I,
    )

    text = re.sub(
        r"</\s*li\s*>",
        "\n",
        text,
        flags=re.I,
    )

    # Structural tags become line breaks.
    text = re.sub(
        r"<\s*br\s*/?\s*>",
        "\n",
        text,
        flags=re.I,
    )

    text = re.sub(
        r"</?\s*(?:p|div|ul|ol)\b[^>]*>",
        "\n",
        text,
        flags=re.I,
    )

    # Formatting tags are removed but their text remains.
    text = RE_INLINE_HTML.sub("", text)

    # --------------------------------------------------------
    # 4. Remove non-semantic contact / navigation noise
    # --------------------------------------------------------

    if remove_urls:
        text = RE_URL.sub(" ", text)

    if remove_emails:
        text = RE_EMAIL.sub(" ", text)

    # --------------------------------------------------------
    # 5. Remove control characters
    # --------------------------------------------------------

    text = RE_CONTROL.sub(" ", text)

    # --------------------------------------------------------
    # 6. Normalize each line
    # --------------------------------------------------------

    cleaned_lines = []

    for line in text.split("\n"):

        # Collapse repeated spaces/tabs inside one line.
        line = RE_MULTI_SPACE.sub(" ", line).strip()

        if not line:
            cleaned_lines.append("")
            continue

        # Normalize only line-leading bullet symbols.
        line = RE_BULLET.sub("- ", line)

        # Avoid accidental duplicated bullet markers.
        line = re.sub(
            r"^-\s*-\s*",
            "- ",
            line,
        )

        cleaned_lines.append(line)

    text = "\n".join(cleaned_lines)

    # --------------------------------------------------------
    # 7. Collapse excessive blank lines
    # --------------------------------------------------------

    text = RE_MANY_BLANK_LINES.sub(
        "\n\n",
        text,
    )

    # 1. 特殊空格统一
    text = re.sub(r"[^\S\n]+", " ", text)

    # 2. inline bullet 转成换行 bullet
    text = re.sub(
        r"\s*[•●▪◦■►∙]\s*",
        "\n- ",
        text
    )

    # 3. 删除裸域名 / 网页路径
    text = re.sub(
        r"(?i)\b(?:[a-z0-9-]+\.)+"
        r"(?:com|org|net|edu|gov|io|co)"
        r"(?:/[^\s]*)?",
        " ",
        text
    )

    # 再整理一次空格
    cleaned_lines = []

    for line in text.split("\n"):
        line = RE_MULTI_SPACE.sub(" ", line).strip()

        if not line:
            cleaned_lines.append("")
            continue

        cleaned_lines.append(line)

    text = "\n".join(cleaned_lines)

    # 最后再压缩多余空行
    text = RE_MANY_BLANK_LINES.sub(
        "\n\n",
        text,
    )

    return text.strip()




# ============================================================
# Run on a CSV
# ============================================================

def main():

    df = pd.read_csv(
        INPUT_FILE,
        dtype=str,
        encoding="utf-8-sig",
    )

    if SOURCE_COLUMN not in df.columns:
        raise KeyError(
            f"Column '{SOURCE_COLUMN}' not found. "
            f"Available columns: {list(df.columns)}"
        )

    # Keep the original DESCRIPTION and add a new cleaned column.
    # This makes auditing much safer.
    df[OUTPUT_COLUMN] = (
        df[SOURCE_COLUMN]
        .apply(clean_description)
    )

    df.to_csv(
        OUTPUT_FILE,
        index=False,
        encoding="utf-8-sig",
    )

    changed = (
        df[SOURCE_COLUMN]
        .fillna("")
        .astype(str)
        .ne(df[OUTPUT_COLUMN])
        .sum()
    )

    empty_after = (
        df[OUTPUT_COLUMN]
        .fillna("")
        .str.strip()
        .eq("")
        .sum()
    )

    print("=" * 80)
    print("DESCRIPTION cleaning complete")
    print("=" * 80)
    print(f"Rows:              {len(df):,}")
    print(f"Changed rows:      {changed:,}")
    print(f"Empty after clean: {empty_after:,}")
    print(f"Output:             {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
