The previous all-mpnet-base-v2 FAISS index was removed because it is incompatible with the new path-aware Qwen3-Embedding retrieval.
Run: python build_taxonomy_index.py --device cuda
