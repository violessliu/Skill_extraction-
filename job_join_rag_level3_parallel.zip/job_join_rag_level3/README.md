# JD-level Lightcast RAG — flattened level-3 skills only

This version treats the Lightcast taxonomy as a **single flat list of the original third-level skill names**.
`category`, `subcategory`, and `skill_id` are not embedded, reranked, shown to the LLM, or saved in extraction outputs.

The bundled taxonomy has **35,518 rows and 35,518 unique third-level skill names**, so flattening does not create name collisions.

## Runtime architecture

The pipeline supports **JD-level batching**. With `--batch-size 16`, up to 16 JDs are processed together while each JD remains an independent model request. vLLM schedules those prompts concurrently; contexts are not concatenated into one giant prompt.

For each batch:

1. Python splits every JD into ordered numbered sentence/bullet units.
2. Sentences across the JD batch are flattened and encoded together with `Qwen/Qwen3-Embedding-4B`.
3. FAISS retrieves a wider candidate pool (default `retrieve_k=32`) from **skill names only**.
4. Exact skill-name matches are added as a lexical safety net.
5. All sentence-candidate pairs in the JD batch are reranked through shared `Qwen/Qwen3-Reranker-4B` batching.
6. The top candidates (default `top_k=8`) for each sentence are restored to their original JD.
7. One prompt is built per JD from all of that JD's numbered sentences + candidates.
8. All JD prompts in the batch are submitted together to vLLM with `llm.generate([...])`. Each JD still has exactly one independent final LLM request.
9. Python validates each JD independently using `sentence_id`, local `candidate_index`, and exact skill name.
10. Outputs keep only the third-level skill name.

So `--batch-size 16` means **16 independent JD prompts scheduled together**, not one prompt containing 16 JDs.

Legacy single-JD behavior is still available with `--batch-size 1`.


Example RAG context:

```text
[1] We require strong Python and SQL skills.

[1]
0 | Python
1 | SQL
2 | Data Analysis
```

Expected model output:

```json
{"results":[{"sentence_id":1,"skills":[{"candidate_index":0,"skill":"Python"},{"candidate_index":1,"skill":"SQL"}]}]}
```

## Optional definition switch

Default behavior embeds/reranks only the skill name:

```text
Python
```

With `--use-definition`:

```text
Python
Definition: ...
```

The build-time and runtime `--use-definition` setting must match.

## Rebuild the FAISS index

This flattened format uses index version 4. Rebuild the index before extraction:

```bash
python build_taxonomy_index.py \
  --embedding-model Qwen/Qwen3-Embedding-4B \
  --device cuda \
  --batch-size 32
```

Definition-aware index:

```bash
python build_taxonomy_index.py \
  --embedding-model Qwen/Qwen3-Embedding-4B \
  --device cuda \
  --batch-size 32 \
  --use-definition
```

## Run extraction

Example:

```bash
python -u run_extraction.py \
  --model qwen3.5-9b \
  --embedding-device cuda:1 \
  --reranker-device cuda:1 \
  --tensor-parallel-size 1 \
  --retrieve-k 32 \
  --top-k 8 \
  --batch-size 16 \
  --embedding-batch-size 64 \
  --reranker-batch-size 32 \
  --checkpoint-every 16
```

For a file whose row count is not 400, add `--expected-rows 0` or set the correct expected count.

### Batch controls

- `--batch-size`: number of JDs grouped for one pipeline batch. Default: `8`. Try `4`, `8`, then `16`.
- `--embedding-batch-size`: internal sentence embedding batch size. This is **not** the number of JDs.
- `--reranker-batch-size`: internal CrossEncoder pair batch size. This is **not** the number of JDs.

Increasing `--batch-size` improves vLLM scheduling/throughput but also raises total KV-cache pressure because more independent prompts are active at the same time. If you hit GPU OOM, lower `--batch-size` first.


## Output

`predictions/qwen3.5-9b/sentence_skills.csv` now contains:

```text
source_index | JOB_HASH | model_alias | sentence_id | sentence | skill
```

Example:

```text
12 | abc123 | qwen3.5-9b | 4 | Experience with Python is required. | Python
```

`sentence_results_json` and `job_level_skills_json` likewise save only the `skill` field.

The original taxonomy CSV is left unchanged as source data, but the pipeline reads only its `skill` column (plus `definition` only when requested).
