from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class TaxonomySkill:
    """One flattened Lightcast leaf skill (former level 3 only)."""

    skill_name: str
    definition: str = ""

    def to_result_dict(self) -> dict[str, str]:
        # Persist only the leaf / former level-3 skill name.
        return {"skill": self.skill_name}


@dataclass(frozen=True)
class SentenceUnit:
    sentence_id: int
    text: str


@dataclass(frozen=True)
class RetrievedSkill:
    """One flattened Lightcast leaf skill retrieved as RAG context."""

    skill: TaxonomySkill
    score: float | None = None
    exact_match: bool = False


def compact_job_skill(skill: TaxonomySkill) -> dict[str, str]:
    return {"skill": skill.skill_name}


def json_safe(value: Any) -> Any:
    try:
        import pandas as pd

        if pd.isna(value):
            return None
    except Exception:
        pass
    if hasattr(value, "item"):
        try:
            return value.item()
        except Exception:
            pass
    return value
