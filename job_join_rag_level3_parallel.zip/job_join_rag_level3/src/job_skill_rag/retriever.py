from __future__ import annotations

import json
from pathlib import Path

from .config import EMBEDDING_INSTRUCTION, RERANKER_INSTRUCTION
from .schema import RetrievedSkill, TaxonomySkill
from .taxonomy import (
    build_exact_name_map,
    load_metadata_jsonl,
    rag_text,
    sentence_ngrams,
)


class LightcastRetriever:
    """Qwen3-Embedding recall + batched Qwen3-Reranker over leaf skill names."""

    def __init__(
        self,
        index_dir: Path,
        embedding_model: str,
        reranker_model: str,
        embedding_device: str = "cpu",
        reranker_device: str = "cpu",
        embedding_instruction: str = EMBEDDING_INSTRUCTION,
        reranker_instruction: str = RERANKER_INSTRUCTION,
        use_definition: bool = False,
    ) -> None:
        try:
            import faiss
            from sentence_transformers import CrossEncoder, SentenceTransformer
        except ImportError as exc:
            raise RuntimeError(
                "Install RAG dependencies: pip install 'sentence-transformers>=5.4.0' "
                "'transformers>=4.51.0' faiss-cpu"
            ) from exc

        metadata_path = index_dir / "taxonomy_metadata.jsonl"
        faiss_path = index_dir / "taxonomy.faiss"
        manifest_path = index_dir / "index_manifest.json"
        model_marker = index_dir / "embedding_model.txt"
        if not metadata_path.exists() or not faiss_path.exists():
            raise FileNotFoundError(
                f"Missing taxonomy index under {index_dir}. Run build_taxonomy_index.py first."
            )

        indexed_model = None
        index_version = None
        indexed_use_definition = False
        if manifest_path.exists():
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            indexed_model = str(manifest.get("embedding_model", "")).strip() or None
            index_version = manifest.get("index_version")
            indexed_use_definition = bool(manifest.get("use_definition", False))
        elif model_marker.exists():
            indexed_model = model_marker.read_text(encoding="utf-8").strip() or None

        if indexed_model and indexed_model != embedding_model:
            raise ValueError(
                "The FAISS index was built with a different embedding model: "
                f"{indexed_model!r} != {embedding_model!r}. Rebuild with: "
                f"python build_taxonomy_index.py --embedding-model {embedding_model}"
            )
        if index_version is not None and int(index_version) < 4:
            raise ValueError(
                "This index predates the flattened level-3-only format. "
                "Rebuild with build_taxonomy_index.py."
            )
        if indexed_use_definition != bool(use_definition):
            requested = "ON" if use_definition else "OFF"
            indexed = "ON" if indexed_use_definition else "OFF"
            flag = " --use-definition" if use_definition else ""
            raise ValueError(
                "Definition mode does not match the FAISS index: "
                f"index={indexed}, runtime={requested}. Rebuild with: "
                f"python build_taxonomy_index.py --embedding-model {embedding_model}{flag}"
            )

        self.skills: list[TaxonomySkill] = load_metadata_jsonl(metadata_path)
        self.index = faiss.read_index(str(faiss_path))
        self.encoder = SentenceTransformer(embedding_model, device=embedding_device)
        self.embedding_instruction = embedding_instruction.strip()
        self.reranker_instruction = reranker_instruction.strip()
        self.use_definition = bool(use_definition)
        self.exact_name_map = build_exact_name_map(self.skills)

        self.reranker = CrossEncoder(
            reranker_model,
            device=reranker_device,
            prompts={"job_skill": self.reranker_instruction},
            default_prompt_name="job_skill",
        )

        if self.index.ntotal != len(self.skills):
            raise ValueError(
                f"Index/metadata mismatch: index={self.index.ntotal}, metadata={len(self.skills)}"
            )

    def _format_query(self, sentence: str) -> str:
        return f"Instruct: {self.embedding_instruction}\nQuery: {sentence}"

    def _exact_hits(self, query: str) -> list[int]:
        grams = sorted(
            sentence_ngrams(query),
            key=lambda value: (len(value.split()), len(value)),
            reverse=True,
        )
        hits: list[int] = []
        seen: set[int] = set()
        for gram in grams:
            if len(gram) < 3:
                continue
            idx = self.exact_name_map.get(gram)
            if idx is not None and idx not in seen:
                hits.append(idx)
                seen.add(idx)
        return hits

    def retrieve_many(
        self,
        queries: list[str],
        sentence_ids: list[int],
        top_k: int,
        retrieve_k: int = 32,
        embedding_batch_size: int = 32,
        reranker_batch_size: int = 8,
    ) -> dict[int, list[RetrievedSkill]]:
        if len(queries) != len(sentence_ids):
            raise ValueError("queries and sentence_ids must have the same length")
        if len(set(sentence_ids)) != len(sentence_ids):
            raise ValueError("sentence_ids must be unique inside one retrieval batch")
        if top_k < 1:
            raise ValueError("top_k must be >= 1")
        if retrieve_k < top_k:
            raise ValueError("retrieve_k must be >= top_k")
        if not queries:
            return {}

        formatted_queries = [self._format_query(query) for query in queries]
        vectors = self.encoder.encode(
            formatted_queries,
            batch_size=embedding_batch_size,
            normalize_embeddings=True,
            convert_to_numpy=True,
            show_progress_bar=False,
        ).astype("float32")

        dense_k = min(len(self.skills), max(retrieve_k, top_k))
        dense_scores, dense_indices = self.index.search(vectors, dense_k)

        pools: list[list[int]] = []
        exact_sets: list[set[int]] = []
        all_pairs: list[tuple[str, str]] = []
        pair_owner: list[tuple[int, int]] = []

        for row_idx, query in enumerate(queries):
            exact_hits = self._exact_hits(query)
            exact_set = set(exact_hits)
            exact_sets.append(exact_set)

            pool: list[int] = []
            seen: set[int] = set()
            for idx in exact_hits:
                if idx not in seen:
                    pool.append(idx)
                    seen.add(idx)

            for idx in dense_indices[row_idx].tolist():
                if idx < 0:
                    continue
                if idx not in seen:
                    pool.append(idx)
                    seen.add(idx)
                if len(pool) >= retrieve_k:
                    break

            pools.append(pool)
            for idx in pool:
                document = rag_text(self.skills[idx], use_definition=self.use_definition)
                all_pairs.append((query, document))
                pair_owner.append((row_idx, idx))

        # One shared cross-encoder call for all sentence-candidate pairs in the
        # JD batch. CrossEncoder still internally chunks by reranker_batch_size.
        if all_pairs:
            all_scores = self.reranker.predict(
                all_pairs,
                batch_size=reranker_batch_size,
                show_progress_bar=False,
            )
        else:
            all_scores = []

        scores_by_row: list[list[tuple[int, float]]] = [[] for _ in queries]
        for (row_idx, idx), score in zip(pair_owner, all_scores):
            scores_by_row[row_idx].append((idx, float(score)))

        output: dict[int, list[RetrievedSkill]] = {}
        for row_idx, sentence_id in enumerate(sentence_ids):
            ranked = sorted(
                scores_by_row[row_idx],
                key=lambda item: item[1],
                reverse=True,
            )[:top_k]
            output[sentence_id] = [
                RetrievedSkill(
                    skill=self.skills[idx],
                    score=score,
                    exact_match=idx in exact_sets[row_idx],
                )
                for idx, score in ranked
            ]

        return output
