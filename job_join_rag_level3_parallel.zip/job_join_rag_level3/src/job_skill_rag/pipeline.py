from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Protocol

from .config import RagConfig
from .prompting import PromptRenderer
from .schema import RetrievedSkill, SentenceUnit, TaxonomySkill, compact_job_skill
from .sentences import split_sentences


class Generator(Protocol):
    def generate(self, system_prompt: str, user_prompt: str) -> str: ...

    def generate_many(self, requests: list[tuple[str, str]]) -> list[str]: ...


class Retriever(Protocol):
    def retrieve_many(
        self,
        queries: list[str],
        sentence_ids: list[int],
        top_k: int,
        retrieve_k: int = 32,
        embedding_batch_size: int = 32,
        reranker_batch_size: int = 8,
    ) -> dict[int, list[RetrievedSkill]]: ...


@dataclass
class ExtractionResult:
    sentence_results: list[dict[str, Any]]
    job_level_skills: list[dict[str, str]]
    n_sentences: int
    n_skill_mentions: int
    n_unique_skills: int


JSON_OBJECT_RE = re.compile(r"\{.*\}", flags=re.DOTALL)


def _parse_json_object(text: str) -> dict[str, Any]:
    text = str(text or "").strip()
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        match = JSON_OBJECT_RE.search(text)
        if not match:
            raise
        value = json.loads(match.group(0))
    if not isinstance(value, dict):
        raise ValueError("Model output must be a JSON object")
    return value


def _parse_results(
    raw: str,
    valid_sentence_ids: set[int],
    retrieved_by_sentence: dict[int, list[RetrievedSkill]],
) -> dict[int, list[RetrievedSkill]]:
    """Validate sentence id + local candidate index + exact flattened skill name."""
    parsed = _parse_json_object(raw)
    items = parsed.get("results")
    if not isinstance(items, list):
        raise ValueError("Output must contain a results list")

    selected: dict[int, list[RetrievedSkill]] = {}
    seen_sentence_ids: set[int] = set()

    for item in items:
        if not isinstance(item, dict):
            raise ValueError("Every results item must be an object")
        try:
            sentence_id = int(item["sentence_id"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError("Every results item needs an integer sentence_id") from exc

        if sentence_id not in valid_sentence_ids:
            raise ValueError(f"Unknown sentence_id={sentence_id}")
        if sentence_id in seen_sentence_ids:
            raise ValueError(f"Duplicate sentence_id={sentence_id}")
        seen_sentence_ids.add(sentence_id)

        skills = item.get("skills")
        if not isinstance(skills, list):
            raise ValueError(f"sentence_id={sentence_id}: skills must be a list")

        retrieved = retrieved_by_sentence.get(sentence_id, [])
        chosen: list[RetrievedSkill] = []
        seen_indices: set[int] = set()

        for output_skill in skills:
            if not isinstance(output_skill, dict):
                raise ValueError(
                    f"sentence_id={sentence_id}: every skills item must be an object"
                )
            try:
                index = int(output_skill["candidate_index"])
            except (KeyError, TypeError, ValueError) as exc:
                raise ValueError(
                    f"sentence_id={sentence_id}: invalid candidate_index"
                ) from exc

            if index < 0 or index >= len(retrieved):
                raise ValueError(
                    f"sentence_id={sentence_id}: candidate_index {index} is out of range"
                )
            if index in seen_indices:
                continue

            candidate = retrieved[index]
            expected = candidate.skill.skill_name
            actual = str(output_skill.get("skill", ""))
            if actual != expected:
                raise ValueError(
                    f"sentence_id={sentence_id}, candidate_index={index}: skill name "
                    "does not exactly match the provided candidate"
                )

            chosen.append(candidate)
            seen_indices.add(index)

        if chosen:
            selected[sentence_id] = chosen

    return selected


class DirectRagPipeline:
    """Batched JD RAG: shared retrieval + one final LLM prompt per JD."""

    RETRY_NOTE = (
        "\n\nYour previous response was invalid. Return ONLY JSON with this schema: "
        '{"results":[{"sentence_id":1,"skills":[{"candidate_index":0,'
        '"skill":"EXACT"}]}]}. '
        "Copy the skill name exactly from the candidate at that local index."
    )

    def __init__(
        self,
        retriever: Retriever,
        generator: Generator,
        prompt_renderer: PromptRenderer,
        config: RagConfig,
        json_retries: int = 1,
    ) -> None:
        self.retriever = retriever
        self.generator = generator
        self.prompt_renderer = prompt_renderer
        self.config = config
        self.json_retries = max(0, int(json_retries))

    def _select_batch(
        self,
        jobs: list[tuple[list[SentenceUnit], dict[int, list[RetrievedSkill]]]],
    ) -> list[dict[int, list[RetrievedSkill]]]:
        """Run one batched vLLM call; retry only JDs whose JSON is invalid."""
        if not jobs:
            return []

        base_prompts = [
            self.prompt_renderer.render(
                sentences=sentences,
                retrieved_by_sentence=retrieved_by_sentence,
            )
            for sentences, retrieved_by_sentence in jobs
        ]
        valid_ids = [
            {unit.sentence_id for unit in sentences}
            for sentences, _ in jobs
        ]

        selected: list[dict[int, list[RetrievedSkill]] | None] = [None] * len(jobs)
        errors: list[Exception | None] = [None] * len(jobs)
        pending = list(range(len(jobs)))

        for attempt in range(self.json_retries + 1):
            if not pending:
                break
            requests: list[tuple[str, str]] = []
            for job_idx in pending:
                system_prompt, user_prompt = base_prompts[job_idx]
                if attempt:
                    user_prompt += self.RETRY_NOTE
                requests.append((system_prompt, user_prompt))

            raw_outputs = self.generator.generate_many(requests)
            if len(raw_outputs) != len(pending):
                raise ValueError(
                    "Generator returned a different number of outputs than batched prompts"
                )

            next_pending: list[int] = []
            for job_idx, raw in zip(pending, raw_outputs):
                try:
                    selected[job_idx] = _parse_results(
                        raw=raw,
                        valid_sentence_ids=valid_ids[job_idx],
                        retrieved_by_sentence=jobs[job_idx][1],
                    )
                except Exception as exc:
                    errors[job_idx] = exc
                    next_pending.append(job_idx)
            pending = next_pending

        if pending:
            details = "; ".join(
                f"batch_item={idx}: {errors[idx]}" for idx in pending
            )
            raise ValueError(f"Invalid grounded RAG JSON after retries: {details}")

        return [item or {} for item in selected]

    @staticmethod
    def _build_result(
        sentences: list[SentenceUnit],
        selected_by_sentence: dict[int, list[RetrievedSkill]],
    ) -> ExtractionResult:
        sentence_lookup = {unit.sentence_id: unit for unit in sentences}
        sentence_results: list[dict[str, Any]] = []
        unique_job_skills: dict[str, TaxonomySkill] = {}
        mentions = 0

        for sentence_id in sorted(selected_by_sentence):
            skill_results: list[dict[str, str]] = []
            seen_skill_names: set[str] = set()

            for item in selected_by_sentence[sentence_id]:
                skill = item.skill
                if skill.skill_name in seen_skill_names:
                    continue
                seen_skill_names.add(skill.skill_name)
                skill_results.append(skill.to_result_dict())
                unique_job_skills.setdefault(skill.skill_name, skill)
                mentions += 1

            if skill_results:
                sentence_results.append(
                    {
                        "sentence_id": sentence_id,
                        "evidence": sentence_lookup[sentence_id].text,
                        "skills": skill_results,
                    }
                )

        return ExtractionResult(
            sentence_results=sentence_results,
            job_level_skills=[
                compact_job_skill(skill) for skill in unique_job_skills.values()
            ],
            n_sentences=len(sentences),
            n_skill_mentions=mentions,
            n_unique_skills=len(unique_job_skills),
        )

    def extract_batch(self, job_descriptions: list[str]) -> list[ExtractionResult]:
        """Extract a batch of JDs with shared embedding/reranking and vLLM batching."""
        if not job_descriptions:
            return []

        sentences_per_job = [split_sentences(description) for description in job_descriptions]
        results: list[ExtractionResult | None] = [None] * len(job_descriptions)

        # Give every sentence a temporary globally unique ID so sentences from
        # different JDs can share one retrieval batch without key collisions.
        flat_queries: list[str] = []
        flat_global_ids: list[int] = []
        global_to_local: dict[int, tuple[int, int]] = {}
        next_global_id = 1

        for job_idx, sentences in enumerate(sentences_per_job):
            if not sentences:
                results[job_idx] = ExtractionResult([], [], 0, 0, 0)
                continue
            for unit in sentences:
                global_id = next_global_id
                next_global_id += 1
                flat_queries.append(unit.text)
                flat_global_ids.append(global_id)
                global_to_local[global_id] = (job_idx, unit.sentence_id)

        retrieved_global = self.retriever.retrieve_many(
            queries=flat_queries,
            sentence_ids=flat_global_ids,
            top_k=self.config.top_k,
            retrieve_k=self.config.retrieve_k,
            embedding_batch_size=self.config.embedding_batch_size,
            reranker_batch_size=self.config.reranker_batch_size,
        )

        retrieved_per_job: list[dict[int, list[RetrievedSkill]]] = [
            {} for _ in job_descriptions
        ]
        for global_id, retrieved in retrieved_global.items():
            job_idx, local_sentence_id = global_to_local[global_id]
            retrieved_per_job[job_idx][local_sentence_id] = retrieved

        nonempty_job_indices = [
            idx for idx, sentences in enumerate(sentences_per_job) if sentences
        ]
        selection_jobs = [
            (sentences_per_job[idx], retrieved_per_job[idx])
            for idx in nonempty_job_indices
        ]
        selected_batch = self._select_batch(selection_jobs)

        for job_idx, selected_by_sentence in zip(nonempty_job_indices, selected_batch):
            results[job_idx] = self._build_result(
                sentences_per_job[job_idx], selected_by_sentence
            )

        return [result or ExtractionResult([], [], 0, 0, 0) for result in results]

    def extract(self, job_description: str) -> ExtractionResult:
        """Single-JD compatibility wrapper."""
        return self.extract_batch([job_description])[0]
