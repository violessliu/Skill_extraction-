from __future__ import annotations

import re

from .schema import SentenceUnit


BULLET_PREFIX_RE = re.compile(r"^\s*(?:[-*•▪◦·]+|\d+[.)]|[A-Za-z][.)])\s*")
INLINE_BULLET_RE = re.compile(r"\s*[•▪◦·]\s*")
SENTENCE_BOUNDARY_RE = re.compile(r"(?<=[.!?])\s+(?=[\"'“‘(\[]?[A-Z0-9])")
WHITESPACE_RE = re.compile(r"[ \t]+")
NOISE_RE = re.compile(r"^[^A-Za-z0-9]{12,}$")


def _clean_piece(text: str) -> str:
    text = BULLET_PREFIX_RE.sub("", text.strip())
    return WHITESPACE_RE.sub(" ", text).strip()


def _is_usable(text: str) -> bool:
    if not text or NOISE_RE.fullmatch(text):
        return False
    return sum(ch.isalnum() for ch in text) >= 2


def split_sentences(text: str) -> list[SentenceUnit]:
    """Split one cleaned JD into ordered sentence/bullet evidence units."""
    text = str(text or "").replace("\\n", "\n")
    text = INLINE_BULLET_RE.sub("\n", text)

    pieces: list[str] = []
    for raw_line in text.splitlines():
        line = _clean_piece(raw_line)
        if not line:
            continue
        for item in SENTENCE_BOUNDARY_RE.split(line):
            item = _clean_piece(item)
            if _is_usable(item):
                pieces.append(item)

    return [SentenceUnit(i + 1, text) for i, text in enumerate(pieces)]
