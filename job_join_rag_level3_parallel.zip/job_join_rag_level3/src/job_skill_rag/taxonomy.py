from __future__ import annotations

import csv
import json
import re
from pathlib import Path

from .schema import TaxonomySkill


# The source CSV may still contain category/subcategory/skill_id columns, but this
# flattened pipeline intentionally uses only the former third-level `skill` column.
REQUIRED_COLUMNS = {"skill"}
NORMALIZE_RE = re.compile(r"[^a-z0-9+#.]+")
TOKEN_RE = re.compile(r"[A-Za-z0-9+#.]+")


def normalize_name(text: str) -> str:
    return NORMALIZE_RE.sub(" ", str(text).casefold()).strip()


def load_taxonomy_csv(path: Path) -> list[TaxonomySkill]:
    if not path.exists():
        raise FileNotFoundError(f"Taxonomy file not found: {path}")

    rows: list[TaxonomySkill] = []
    seen_names: set[str] = set()
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        missing = REQUIRED_COLUMNS - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"Taxonomy is missing columns: {sorted(missing)}")

        for row in reader:
            skill_name = str(row["skill"]).strip()
            normalized = normalize_name(skill_name)
            if not skill_name or not normalized:
                continue
            if normalized in seen_names:
                raise ValueError(
                    "Flattened taxonomy requires unique level-3 skill names, but found "
                    f"duplicate: {skill_name!r}"
                )
            seen_names.add(normalized)
            rows.append(
                TaxonomySkill(
                    skill_name=skill_name,
                    definition=str(row.get("definition", "") or "").strip(),
                )
            )

    if not rows:
        raise ValueError("Taxonomy contains no usable skills")
    return rows


def rag_text(skill: TaxonomySkill, use_definition: bool = False) -> str:
    """Document embedded/reranked for one flattened leaf skill."""
    if use_definition and skill.definition:
        return f"{skill.skill_name}\nDefinition: {skill.definition}"
    return skill.skill_name


def save_metadata_jsonl(
    skills: list[TaxonomySkill],
    path: Path,
    include_definition: bool = False,
) -> None:
    """Save only the flattened skill name (+ optional definition)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for skill in skills:
            record = {"skill_name": skill.skill_name}
            if include_definition:
                record["definition"] = skill.definition
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def load_metadata_jsonl(path: Path) -> list[TaxonomySkill]:
    skills: list[TaxonomySkill] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                data = json.loads(line)
                skills.append(
                    TaxonomySkill(
                        skill_name=str(data["skill_name"]).strip(),
                        definition=str(data.get("definition", "") or "").strip(),
                    )
                )
    return skills


def build_exact_name_map(skills: list[TaxonomySkill]) -> dict[str, int]:
    return {normalize_name(skill.skill_name): i for i, skill in enumerate(skills)}


def sentence_ngrams(text: str, max_n: int = 7) -> set[str]:
    tokens = [token.casefold() for token in TOKEN_RE.findall(str(text))]
    grams: set[str] = set()
    for n in range(1, min(max_n, len(tokens)) + 1):
        for i in range(0, len(tokens) - n + 1):
            grams.add(normalize_name(" ".join(tokens[i : i + n])))
    return grams
