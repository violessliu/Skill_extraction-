from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .config import ModelSpec


@dataclass(frozen=True)
class GenerationConfig:
    temperature: float = 0.0
    max_tokens: int = 1600
    top_p: float = 1.0


class VLLMBackend:
    """Shared vLLM backend with native multi-prompt batching."""

    def __init__(
        self,
        spec: ModelSpec,
        tensor_parallel_size: int = 1,
        gpu_memory_utilization: float = 0.90,
        max_model_len: int | None = None,
        generation: GenerationConfig | None = None,
    ) -> None:
        try:
            from vllm import LLM, SamplingParams
        except ImportError as exc:
            raise RuntimeError("Install vLLM before running extraction: pip install vllm") from exc

        llm_kwargs: dict[str, Any] = {
            "model": spec.model_id,
            "tensor_parallel_size": tensor_parallel_size,
            "gpu_memory_utilization": gpu_memory_utilization,
            "trust_remote_code": False,
        }

        if "Ministral-3" in spec.model_id:
            llm_kwargs.update(
                {
                    "tokenizer_mode": "mistral",
                    "config_format": "mistral",
                    "load_format": "mistral",
                }
            )

        if spec.language_model_only:
            # Qwen3.5 is multimodal, but this pipeline is text-only. Disabling
            # image/video inputs avoids loading/profiling unused multimodal capacity.
            llm_kwargs["limit_mm_per_prompt"] = {"image": 0, "video": 0}

        if max_model_len is not None:
            llm_kwargs["max_model_len"] = max_model_len

        self.spec = spec
        self.llm = LLM(**llm_kwargs)
        gen = generation or GenerationConfig()
        self.sampling_params = SamplingParams(
            temperature=gen.temperature,
            top_p=gen.top_p,
            max_tokens=gen.max_tokens,
        )

    def _messages(self, system_prompt: str, user_prompt: str) -> list[dict[str, str]]:
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def generate_many(self, requests: list[tuple[str, str]]) -> list[str]:
        """Generate multiple independent JD prompts in one vLLM batch."""
        if not requests:
            return []

        message_batches = [self._messages(system, user) for system, user in requests]

        # Prefer explicit chat-template rendering. This lets vLLM schedule all
        # prompts together while still honoring Qwen's enable_thinking=False.
        try:
            tokenizer = self.llm.get_tokenizer()
            prompts: list[str] = []
            for messages in message_batches:
                template_kwargs: dict[str, Any] = {
                    "tokenize": False,
                    "add_generation_prompt": True,
                }
                template_kwargs.update(self.spec.chat_template_kwargs)
                prompts.append(tokenizer.apply_chat_template(messages, **template_kwargs))

            outputs = self.llm.generate(prompts, self.sampling_params, use_tqdm=False)
            return [output.outputs[0].text.strip() for output in outputs]
        except (TypeError, AttributeError):
            # Compatibility fallback for vLLM/tokenizer versions whose chat
            # template does not accept model-specific kwargs.
            fallback_batches = []
            for messages in message_batches:
                copied = [dict(message) for message in messages]
                if self.spec.chat_template_kwargs:
                    copied[-1]["content"] = copied[-1]["content"] + "\n\n/no_think"
                fallback_batches.append(copied)

            kwargs: dict[str, Any] = {
                "messages": fallback_batches,
                "sampling_params": self.sampling_params,
                "use_tqdm": False,
            }
            try:
                outputs = self.llm.chat(**kwargs)
            except TypeError:
                # Last-resort compatibility path: render without extra kwargs,
                # but still submit all prompts to generate() together.
                tokenizer = self.llm.get_tokenizer()
                prompts = [
                    tokenizer.apply_chat_template(
                        messages, tokenize=False, add_generation_prompt=True
                    )
                    for messages in fallback_batches
                ]
                outputs = self.llm.generate(prompts, self.sampling_params, use_tqdm=False)

            return [output.outputs[0].text.strip() for output in outputs]

    def generate(self, system_prompt: str, user_prompt: str) -> str:
        """Single-prompt compatibility wrapper."""
        return self.generate_many([(system_prompt, user_prompt)])[0]
