from __future__ import annotations

from pathlib import Path

from .schema import RetrievedSkill, SentenceUnit


class PromptRenderer:
    """Render one prompt per JD; all numbered sentences are judged in one LLM call."""

    def __init__(self, prompt_dir: Path, use_definition: bool = False) -> None:
        self.use_definition = bool(use_definition)
        self.system_prompt = (prompt_dir / "system.txt").read_text(encoding="utf-8").strip()
        self.user_template = (prompt_dir / "extract_sentences.txt").read_text(
            encoding="utf-8"
        ).strip()

    @staticmethod
    def _numbered_sentences(sentences: list[SentenceUnit]) -> str:
        return "\n".join(f"[{unit.sentence_id}] {unit.text}" for unit in sentences)

    def _candidate_blocks(
        self,
        sentences: list[SentenceUnit],
        retrieved_by_sentence: dict[int, list[RetrievedSkill]],
    ) -> str:
        blocks: list[str] = []
        for sentence in sentences:
            lines = [f"[{sentence.sentence_id}]"]
            retrieved = retrieved_by_sentence.get(sentence.sentence_id, [])
            if not retrieved:
                lines.append("(no candidates)")
            else:
                for index, item in enumerate(retrieved):
                    skill = item.skill
                    line = f"{index} | {skill.skill_name}"
                    if self.use_definition and skill.definition:
                        definition = " ".join(skill.definition.split())
                        line += f" | Definition: {definition}"
                    lines.append(line)
            blocks.append("\n".join(lines))
        return "\n\n".join(blocks)

    def render(
        self,
        sentences: list[SentenceUnit],
        retrieved_by_sentence: dict[int, list[RetrievedSkill]],
    ) -> tuple[str, str]:
        user_prompt = (
            self.user_template
            .replace("{{NUMBERED_SENTENCES}}", self._numbered_sentences(sentences))
            .replace("{{RAG_CANDIDATES}}", self._candidate_blocks(sentences, retrieved_by_sentence))
        )
        return self.system_prompt, user_prompt
