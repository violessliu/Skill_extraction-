from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DATA_FILE = PROJECT_ROOT / "data" / "sample_2021_2025_400.csv"
DEFAULT_TAXONOMY_FILE = PROJECT_ROOT / "taxonomy" / "final_lightcast_taxonomy.csv"
DEFAULT_INDEX_DIR = PROJECT_ROOT / "index"
DEFAULT_PROMPT_DIR = PROJECT_ROOT / "prompts"
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "predictions"
DEFAULT_TEXT_COLUMN = "DESCRIPTION_CLEAN"

# Retrieval stack: Qwen3 dense retrieval -> Qwen3 cross-encoder reranking.
DEFAULT_EMBEDDING_MODEL = "Qwen/Qwen3-Embedding-4B"
DEFAULT_RERANKER_MODEL = "Qwen/Qwen3-Reranker-4B"

# Qwen3 embedding/reranker are instruction-aware. Keep the instruction strict:
# retrieval is candidate generation for skills the employer actually asks for,
# not generic topic similarity.
EMBEDDING_INSTRUCTION = (
    "Given one sentence from a job description, retrieve Lightcast leaf skill names "
    "that best match skills, knowledge, tools, technologies, methods, or capabilities "
    "the employer explicitly requires, prefers, or directly expects the employee to use. "
    "Do not treat company background, job titles, education or years of experience alone, "
    "benefits, legal boilerplate, or merely related concepts as skill evidence."
)

RERANKER_INSTRUCTION = (
    "Rank each Lightcast leaf skill name for one job-description sentence. A skill is relevant "
    "only when it accurately represents a skill, knowledge area, tool, technology, method, or "
    "capability that the employer explicitly requires, prefers, or directly expects the employee "
    "to use in that sentence. Do not reward generic topical similarity or inferred skills."
)


@dataclass(frozen=True)
class ModelSpec:
    model_id: str
    chat_template_kwargs: dict[str, object] = field(default_factory=dict)
    language_model_only: bool = False


MODEL_SPECS: dict[str, ModelSpec] = {
    "qwen3-14b": ModelSpec(
        model_id="Qwen/Qwen3-14B",
        chat_template_kwargs={"enable_thinking": False},
    ),
    "qwen3.5-9b": ModelSpec(
        model_id="Qwen/Qwen3.5-9B",
        chat_template_kwargs={"enable_thinking": False},
        language_model_only=True,
    ),
    "ministral3-14b": ModelSpec(
        model_id="mistralai/Ministral-3-14B-Instruct-2512",
    ),
}


@dataclass(frozen=True)
class RagConfig:
    # Dense retrieval creates a wider pool; reranker reduces it to top_k.
    retrieve_k: int = 32
    top_k: int = 8
    embedding_batch_size: int = 32
    reranker_batch_size: int = 8
