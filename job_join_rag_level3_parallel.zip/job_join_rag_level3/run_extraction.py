from __future__ import annotations

import argparse
import gc
import json
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parent
SRC_DIR = PROJECT_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from job_skill_rag.backend import GenerationConfig, VLLMBackend  # noqa: E402
from job_skill_rag.config import (  # noqa: E402
    DEFAULT_DATA_FILE,
    DEFAULT_EMBEDDING_MODEL,
    DEFAULT_INDEX_DIR,
    DEFAULT_RERANKER_MODEL,
    DEFAULT_OUTPUT_DIR,
    DEFAULT_PROMPT_DIR,
    DEFAULT_TEXT_COLUMN,
    MODEL_SPECS,
    RagConfig,
)
from job_skill_rag.pipeline import DirectRagPipeline  # noqa: E402
from job_skill_rag.prompting import PromptRenderer  # noqa: E402
from job_skill_rag.retriever import LightcastRetriever  # noqa: E402
from job_skill_rag.schema import json_safe  # noqa: E402


def json_dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def output_paths(model_alias: str, output_dir: Path) -> tuple[Path, Path]:
    model_dir = output_dir / model_alias
    model_dir.mkdir(parents=True, exist_ok=True)
    return model_dir / "results.csv", model_dir / "results.jsonl"


def load_prior_rows(csv_path: Path, id_column: str) -> tuple[list[dict[str, Any]], set[str]]:
    """Load completed rows for stable resume using JOB_HASH (or another ID column)."""
    if not csv_path.exists():
        return [], set()
    prior = pd.read_csv(csv_path, dtype=str, keep_default_na=False)
    if "source_index" in prior.columns:
        prior["source_index"] = pd.to_numeric(prior["source_index"], errors="coerce").fillna(-1).astype(int)
    done: set[str] = set()
    if {id_column, "status"}.issubset(prior.columns):
        valid = prior["status"].isin(["ok", "empty_description"])
        done = set(prior.loc[valid, id_column].astype(str).tolist())
    return prior.to_dict("records"), done


def save_results(
    rows: list[dict[str, Any]],
    input_columns: list[str],
    id_column: str,
    csv_path: Path,
    jsonl_path: Path,
) -> None:
    if not rows:
        return
    runtime_columns = [
        "source_index",
        "model_alias",
        "model_id",
        "status",
        "n_sentences",
        "n_skill_mentions",
        "n_unique_skills",
        "sentence_results_json",
        "job_level_skills_json",
        "error",
    ]
    columns = list(dict.fromkeys(input_columns + runtime_columns))
    frame = pd.DataFrame(rows)
    for column in columns:
        if column not in frame.columns:
            frame[column] = ""
    frame = frame[columns].sort_values("source_index")
    frame.to_csv(csv_path, index=False, encoding="utf-8-sig")

    # Convenience long-format output: one row per sentence-skill pair.
    long_rows: list[dict[str, Any]] = []
    for source_row in frame.to_dict("records"):
        try:
            sentence_results = json.loads(source_row.get("sentence_results_json") or "[]")
        except Exception:
            sentence_results = []
        for sentence_result in sentence_results:
            for skill in sentence_result.get("skills", []):
                long_rows.append(
                    {
                        "source_index": source_row.get("source_index", ""),
                        id_column: source_row.get(id_column, ""),
                        "model_alias": source_row.get("model_alias", ""),
                        "sentence_id": sentence_result.get("sentence_id", ""),
                        "sentence": sentence_result.get("evidence", ""),
                        "skill": skill.get("skill", ""),
                    }
                )
    long_columns = [
        "source_index", id_column, "model_alias", "sentence_id", "sentence", "skill"
    ]
    pd.DataFrame(long_rows, columns=long_columns).to_csv(
        csv_path.with_name("sentence_skills.csv"), index=False, encoding="utf-8-sig"
    )

    with jsonl_path.open("w", encoding="utf-8") as handle:
        for row in frame.to_dict("records"):
            record = {
                key: json_safe(value)
                for key, value in row.items()
                if key not in {"sentence_results_json", "job_level_skills_json"}
            }
            try:
                record["sentence_results"] = json.loads(row["sentence_results_json"] or "[]")
            except Exception:
                record["sentence_results"] = []
            try:
                record["job_level_skills"] = json.loads(row["job_level_skills_json"] or "[]")
            except Exception:
                record["job_level_skills"] = []
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def run_model(
    model_alias: str,
    samples: pd.DataFrame,
    input_columns: list[str],
    retriever: LightcastRetriever,
    prompt_renderer: PromptRenderer,
    rag_config: RagConfig,
    args: argparse.Namespace,
) -> None:
    spec = MODEL_SPECS[model_alias]
    csv_path, jsonl_path = output_paths(model_alias, args.output_dir)
    prior_rows, done_ids = (
        load_prior_rows(csv_path, args.id_column) if args.resume else ([], set())
    )
    rows_by_index: dict[int, dict[str, Any]] = {
        int(row.get("source_index", -1)): row for row in prior_rows
    }

    backend = VLLMBackend(
        spec=spec,
        tensor_parallel_size=args.tensor_parallel_size,
        gpu_memory_utilization=args.gpu_memory_utilization,
        max_model_len=args.max_model_len,
        generation=GenerationConfig(
            temperature=args.temperature,
            max_tokens=args.max_new_tokens,
        ),
    )
    pipeline = DirectRagPipeline(
        retriever=retriever,
        generator=backend,
        prompt_renderer=prompt_renderer,
        config=rag_config,
        json_retries=args.json_retries,
    )

    shutdown = {"requested": False}

    def handle_signal(signum: int, _frame: Any) -> None:
        print(f"\nSignal {signum}; checkpointing before exit.", flush=True)
        shutdown["requested"] = True

    signal.signal(signal.SIGINT, handle_signal)
    try:
        signal.signal(signal.SIGTERM, handle_signal)
    except (AttributeError, ValueError):
        pass

    pending: list[tuple[int, pd.Series]] = []
    for source_index, sample in samples.iterrows():
        source_index = int(source_index)
        record_id = str(sample.get(args.id_column, "")).strip() or str(source_index)
        if record_id not in done_ids:
            pending.append((source_index, sample))

    processed = 0
    next_checkpoint = args.checkpoint_every
    started = time.time()

    for batch_start in range(0, len(pending), args.batch_size):
        if shutdown["requested"]:
            break

        batch_items = pending[batch_start : batch_start + args.batch_size]
        prepared_rows: list[dict[str, Any]] = []
        descriptions: list[str] = []
        extraction_positions: list[int] = []

        for batch_pos, (source_index, sample) in enumerate(batch_items):
            row = sample.to_dict()
            row.update(
                {
                    "source_index": source_index,
                    "model_alias": model_alias,
                    "model_id": spec.model_id,
                    "status": "",
                    "n_sentences": 0,
                    "n_skill_mentions": 0,
                    "n_unique_skills": 0,
                    "sentence_results_json": "[]",
                    "job_level_skills_json": "[]",
                    "error": "",
                }
            )
            prepared_rows.append(row)

            description_value = sample.get(args.text_column)
            description = "" if pd.isna(description_value) else str(description_value).strip()
            if not description:
                row["status"] = "empty_description"
            else:
                extraction_positions.append(batch_pos)
                descriptions.append(description)

        if descriptions:
            try:
                batch_results = pipeline.extract_batch(descriptions)
                for batch_pos, result in zip(extraction_positions, batch_results):
                    prepared_rows[batch_pos].update(
                        {
                            "status": "ok",
                            "n_sentences": result.n_sentences,
                            "n_skill_mentions": result.n_skill_mentions,
                            "n_unique_skills": result.n_unique_skills,
                            "sentence_results_json": json_dumps(result.sentence_results),
                            "job_level_skills_json": json_dumps(result.job_level_skills),
                        }
                    )
            except Exception as batch_exc:
                # Rare malformed output should not destroy the whole JD batch.
                # Fall back to one-JD calls so good rows can still complete.
                print(
                    f"batch {batch_start // args.batch_size + 1} ERROR: "
                    f"{type(batch_exc).__name__}: {batch_exc}; retrying rows individually",
                    flush=True,
                )
                for batch_pos, description in zip(extraction_positions, descriptions):
                    try:
                        result = pipeline.extract(description)
                        prepared_rows[batch_pos].update(
                            {
                                "status": "ok",
                                "n_sentences": result.n_sentences,
                                "n_skill_mentions": result.n_skill_mentions,
                                "n_unique_skills": result.n_unique_skills,
                                "sentence_results_json": json_dumps(result.sentence_results),
                                "job_level_skills_json": json_dumps(result.job_level_skills),
                            }
                        )
                    except Exception as exc:
                        prepared_rows[batch_pos]["status"] = "error"
                        prepared_rows[batch_pos]["error"] = f"{type(exc).__name__}: {exc}"
                        source_index = prepared_rows[batch_pos]["source_index"]
                        print(
                            f"row {source_index} ERROR: {prepared_rows[batch_pos]['error']}",
                            flush=True,
                        )

        for row in prepared_rows:
            rows_by_index[int(row["source_index"])] = row

        processed += len(batch_items)
        elapsed = time.time() - started
        rate = processed / elapsed if elapsed > 0 else 0.0
        print(
            f"{model_alias}: batch={batch_start // args.batch_size + 1} "
            f"size={len(batch_items)} | {processed}/{len(pending)} new rows | "
            f"elapsed={elapsed/60:.1f} min | {rate:.2f} JD/s",
            flush=True,
        )

        if processed >= next_checkpoint:
            save_results(
                list(rows_by_index.values()),
                input_columns,
                args.id_column,
                csv_path,
                jsonl_path,
            )
            while next_checkpoint <= processed:
                next_checkpoint += args.checkpoint_every
            print("checkpoint saved", flush=True)

    save_results(
        list(rows_by_index.values()),
        input_columns,
        args.id_column,
        csv_path,
        jsonl_path,
    )
    print(f"Final CSV:  {csv_path}")
    print(f"Final JSONL:{jsonl_path}")

    del pipeline, backend
    gc.collect()
    try:
        import torch

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:
        pass

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Direct RAG skill extraction grounded in the Lightcast taxonomy."
    )
    parser.add_argument("--model", required=True, choices=[*MODEL_SPECS, "all"])
    parser.add_argument("--data-file", type=Path, default=DEFAULT_DATA_FILE)
    parser.add_argument("--text-column", default=DEFAULT_TEXT_COLUMN)
    parser.add_argument(
        "--id-column",
        default="JOB_HASH",
        help="Stable row identifier used for resume; defaults to JOB_HASH.",
    )
    parser.add_argument(
        "--expected-rows",
        type=int,
        default=400,
        help="Expected pilot size. Use 0 to disable the row-count check.",
    )
    parser.add_argument("--index-dir", type=Path, default=DEFAULT_INDEX_DIR)
    parser.add_argument("--prompt-dir", type=Path, default=DEFAULT_PROMPT_DIR)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--embedding-model", default=DEFAULT_EMBEDDING_MODEL)
    parser.add_argument("--reranker-model", default=DEFAULT_RERANKER_MODEL)
    parser.add_argument(
        "--use-definition",
        action="store_true",
        help=(
            "Include Lightcast definitions in flattened skill reranking and Qwen3.5 RAG context. "
            "Default is OFF. The FAISS index must have been built with the same setting."
        ),
    )
    parser.add_argument(
        "--embedding-device",
        default="cpu",
        help="Qwen3 embedding device, e.g. cpu, cuda, cuda:1.",
    )
    parser.add_argument(
        "--reranker-device",
        default="cpu",
        help="Qwen3 reranker device, e.g. cpu, cuda, cuda:1.",
    )
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--resume", action="store_true")

    parser.add_argument(
        "--retrieve-k",
        type=int,
        default=32,
        help="Qwen3-Embedding candidate pool per sentence before reranking.",
    )
    parser.add_argument(
        "--top-k",
        type=int,
        default=8,
        help="Qwen3-Reranker finalists per sentence shown to Qwen3.5.",
    )
    parser.add_argument("--embedding-batch-size", type=int, default=32)
    parser.add_argument("--reranker-batch-size", type=int, default=8)
    parser.add_argument(
        "--batch-size",
        type=int,
        default=8,
        help="Number of JDs processed together for retrieval/reranking/vLLM batching.",
    )

    parser.add_argument("--tensor-parallel-size", type=int, default=1)
    parser.add_argument("--gpu-memory-utilization", type=float, default=0.90)
    parser.add_argument("--max-model-len", type=int, default=None)
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--max-new-tokens", type=int, default=1600)
    parser.add_argument("--json-retries", type=int, default=1)
    parser.add_argument("--checkpoint-every", type=int, default=10)
    return parser


def _run_all_in_fresh_processes() -> None:
    """Run each LLM in a fresh process so vLLM GPU memory is fully released."""
    original = sys.argv[1:]
    forwarded: list[str] = []
    skip_next = False
    for index, value in enumerate(original):
        if skip_next:
            skip_next = False
            continue
        if value == "--model":
            skip_next = True
            continue
        if value.startswith("--model="):
            continue
        forwarded.append(value)

    for alias in MODEL_SPECS:
        command = [sys.executable, str(Path(__file__).resolve()), "--model", alias, *forwarded]
        print("\n>>> launching:", " ".join(command), flush=True)
        subprocess.run(command, check=True)


def main() -> None:
    args = build_parser().parse_args()
    if args.batch_size < 1:
        raise ValueError("--batch-size must be >= 1")
    if args.checkpoint_every < 1:
        raise ValueError("--checkpoint-every must be >= 1")
    if args.model == "all":
        _run_all_in_fresh_processes()
        return
    args.data_file = args.data_file.resolve()
    args.index_dir = args.index_dir.resolve()
    args.prompt_dir = args.prompt_dir.resolve()
    args.output_dir = args.output_dir.resolve()

    samples = pd.read_csv(args.data_file, dtype=str, keep_default_na=False).reset_index(drop=True)
    if args.text_column not in samples.columns:
        raise KeyError(
            f"Column '{args.text_column}' not found. Available: {', '.join(samples.columns)}"
        )
    if args.id_column not in samples.columns:
        raise KeyError(
            f"ID column '{args.id_column}' not found. Available: {', '.join(samples.columns)}"
        )
    if args.expected_rows and len(samples) != args.expected_rows:
        raise ValueError(
            f"Expected {args.expected_rows} pilot rows, but found {len(samples)} in {args.data_file}"
        )

    usable = samples[args.text_column].astype(str).str.strip().ne("")
    print(f"Input rows: {len(samples):,}")
    print(f"Usable {args.text_column}: {int(usable.sum()):,}")
    print(f"Empty {args.text_column}: {int((~usable).sum()):,}")
    print(f"Unique {args.id_column}: {samples[args.id_column].nunique():,}")
    print(f"Definition mode: {'ON' if args.use_definition else 'OFF'}")

    if args.limit is not None:
        if args.limit < 1:
            raise ValueError("--limit must be >= 1")
        samples = samples.head(args.limit)

    input_columns = list(samples.columns)
    retriever = LightcastRetriever(
        index_dir=args.index_dir,
        embedding_model=args.embedding_model,
        reranker_model=args.reranker_model,
        embedding_device=args.embedding_device,
        reranker_device=args.reranker_device,
        use_definition=args.use_definition,
    )
    prompt_renderer = PromptRenderer(args.prompt_dir, use_definition=args.use_definition)
    rag_config = RagConfig(
        retrieve_k=args.retrieve_k,
        top_k=args.top_k,
        embedding_batch_size=args.embedding_batch_size,
        reranker_batch_size=args.reranker_batch_size,
    )

    run_model(
        model_alias=args.model,
        samples=samples,
        input_columns=input_columns,
        retriever=retriever,
        prompt_renderer=prompt_renderer,
        rag_config=rag_config,
        args=args,
    )


if __name__ == "__main__":
    main()
